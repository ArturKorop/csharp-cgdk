﻿using Com.CodeGame.CodeTroopers2013.DevKit.CSharpCgdk.Model;

namespace Com.CodeGame.CodeTroopers2013.DevKit.CSharpCgdk
{
    public class CommanderBehavior : DefaultBehavior
    {
        public CommanderBehavior(World world, Trooper self, Game game)
            : base(world, self, game)
        {
        }
    }
}